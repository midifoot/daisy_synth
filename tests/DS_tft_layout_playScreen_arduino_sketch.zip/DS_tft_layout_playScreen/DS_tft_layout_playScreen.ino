/**
 * PROJECT: MDS (MFKB Daisy Synth)
 * MODULE: UI Layout Validation
 * VERSION: 1.1 (Updated Row 1 with SD Storage)
 * ---------------------------------------------------------
 * ROW HEIGHT: 16px | TOTAL ROWS: 8
 * COLORS: 
 * - Orange: Preview/Browse Mode
 * - Cyan: Active Sequencer
 * - Green/Red: System Status
 * ---------------------------------------------------------
 */

#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>

// --- UPDATED PIN DEFINITIONS (Daisy Seed v1.2) ---
// Based on Daisy Seed v1.2 Digital Labels
#define TFT_CS    21   // Physical Pin 28 (D21)
#define TFT_SCLK  22   // Physical Pin 29 (D22)
#define TFT_MOSI  23   // Physical Pin 30 (D23)
#define TFT_DC    24   // Physical Pin 31 (D24)
#define TFT_RST   25   // Physical Pin 32 (D25)

// --- COLOR PALETTE (RGB565) ---
#define MDS_BLACK   0x0000
#define MDS_WHITE   0xFFFF
#define MDS_CYAN    0x07FF
#define MDS_ORANGE  0xFD20
#define MDS_GREEN   0x07E0
#define MDS_GREY    0x7BEF
#define MDS_RED     0xF800

// We now pass MOSI and SCLK explicitly because we moved to SPI2 pins
Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);

void setup() {
  tft.initR(INITR_BLACKTAB); 
  tft.setRotation(1); // Landscape 160x128
  drawFullUI();
}

/**
 * Helper to determine color based on percentage thresholds:
 * Green <= 75%, Orange 76-95%, Red > 95%
 */
uint16_t getThresholdColor(int val) {
  if (val <= 75) return MDS_GREEN;
  if (val <= 95) return MDS_ORANGE;
  return MDS_RED;
}

void drawFullUI() {
  tft.fillScreen(MDS_BLACK);

  // --- ROW 1: SYSTEM HEADER (0-15px) ---
  tft.setTextSize(1);
  tft.setTextColor(MDS_WHITE);
  tft.setCursor(1, 4);
  tft.print("[O]");

  // Inverted text to show encoder3 focus / toggle  
  tft.setCursor(22, 4);
  tft.setTextColor(MDS_BLACK, MDS_CYAN); 
  tft.print("100");

  // SEPARATOR & MIX (Normal colors)
  tft.setTextColor(MDS_WHITE, MDS_BLACK);
  tft.print("/");
  tft.print("57");

  // Symbolic VU Meter (Displaced to the left to make room)
  // Coordinates shifted: 60, 65, 70, 75, 80
  tft.fillRect(60, 4, 4, 8, MDS_GREEN);
  tft.fillRect(66, 3, 4, 9, MDS_GREEN);
  tft.fillRect(72, 2, 4, 10, MDS_GREEN);
  tft.fillRect(78, 1, 4, 11, MDS_ORANGE);
  tft.fillRect(84, 0, 4, 12, MDS_RED);

  // CPU Load Indicator (85% -> Orange)
  int cpuLoad = 85; 
  tft.setCursor(92, 4);
  tft.setTextColor(getThresholdColor(cpuLoad));
  tft.print(cpuLoad);
  tft.print("%");

  // SD Space Indicator (24% -> Green)
  int sdSpace = 24;
  tft.setCursor(114, 4);
  tft.setTextColor(getThresholdColor(sdSpace));
  tft.print(sdSpace);
  tft.print("%");

  // Mode Indicator
  tft.setCursor(136, 4);
  tft.setTextColor(MDS_WHITE);
  tft.print("PLAY");

  // --- ROW 2: SYSTEM MESSAGE (16-32px) ---
  tft.fillRect(0, 14, 160, 16, MDS_GREEN);
  tft.setTextColor(MDS_BLACK);
  tft.setCursor(2, 19);
  tft.print("STATUS: SYSTEM READY");
  tft.drawFastHLine(0, 31, 160, MDS_WHITE);

  // --- ROW 3-4: ACTIVE PATCH (32-63px) ---
  tft.fillRect(0, 33, 160, 24, MDS_ORANGE);
  tft.setTextColor(MDS_BLACK);
  tft.setTextSize(2);
  tft.setCursor(2, 38);
  tft.print("024:ARCADE Bs");

  // --- ROW 5: MODULE RECAP (64-79px) ---
  tft.setTextSize(1);
  tft.setTextColor(MDS_WHITE);
  tft.setCursor(2, 59);
  tft.print("WAVE | LADDER_F | REVERB");

  // --- ROW 6: PHRASE NAME (80-95px) ---
  tft.drawFastHLine(0, 68, 160, MDS_WHITE);
  tft.fillRect(0, 70, 160, 16, MDS_ORANGE);
  tft.setTextColor(MDS_BLACK);
  tft.setCursor(2, 74);
  tft.print("PHR: 012  acid_line_01");

  // --- ROW 7: PHRASE DETAILS (96-111px) ---
  tft.setTextColor(MDS_WHITE);
  tft.setCursor(2, 88);
  tft.print("BPM:120   TS:4/4   LEN:16");

  // --- ROW 8: FOOTER LEGEND (112-127px) ---
  tft.drawFastHLine(0, 97, 160, MDS_WHITE);
  tft.setCursor(2, 101);
  tft.setTextColor(MDS_CYAN);
  tft.print("R1-3 BROWSE / SET");
  tft.setCursor(2, 110);
  tft.print("P1-3 SELECT / TOGGLE");  
  tft.setTextColor(MDS_RED);
  tft.setCursor(2, 119);
  tft.print("[R]:edit PAT");
  tft.setTextColor(MDS_GREEN);
  tft.print(" [G]:edit PHR");
}

void loop() {
  // Static for now
}